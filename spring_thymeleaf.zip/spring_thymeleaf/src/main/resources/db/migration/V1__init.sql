create table if not exists products (id bigserial primary key, name varchar(255),cost int);


insert into products (name, cost)
values
('Product1', 100),
('Product2', 102),
('Product3', 103),
('Product4', 103),
('Product5', 104),
('Product6', 105),
('Product7', 106),
('Product8', 107),
('Product9', 108),
('Product10',109),
('Product11', 110),
('Product12', 111),
('Product13', 112),
('Product14', 113),
('Product15', 114),
('Product16', 115),
('Product17', 116),
('Product18', 117),
('Product19', 118),
('Product20',119);
